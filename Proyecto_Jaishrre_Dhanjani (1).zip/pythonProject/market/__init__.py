from flask import Flask
from flask_bcrypt import Bcrypt
from flask_login import LoginManager


app = Flask(__name__)
app.config["SECRET_KEY"] = '1adf2bc1b1e6677a1c638511' # This is to display the form created
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = "login_page"
login_manager.login_message = "Debes iniciar sesión para poder acceder a esta página"
login_manager.login_message_category = "info"
from market import routes