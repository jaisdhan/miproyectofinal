from market import app
from flask import render_template, redirect, url_for,flash, request
from market.models import Item, User
from market.forms import  RegisterForm, LoginForm, PurchaseItemForm, SellItemForm
from market import db
from flask_login import login_user, logout_user, login_required,current_user


@app.route("/")
def home_page():
    return render_template("index.html")

@app.route('/market', methods=["GET", "POST"])
@login_required
def market_page():
    purchase_form = PurchaseItemForm()
    sell_form = SellItemForm()
    if request.method == "POST":
        producto_adquirido = request.form.get("producto_adquirido")
        p_adquirido = db.session.query(Item).filter_by(nombre=producto_adquirido).first()
        if p_adquirido:
            if current_user.can_purchase(p_adquirido):
                p_adquirido.comprar(current_user)
                flash(f"Enhorabuena, has comprado {p_adquirido.nombre} a {p_adquirido.precio}€", category="success")
            else:
                flash(f"No tienes dinero suficiente para comprar {p_adquirido.nombre}", category="danger")

        producto_vendido = request.form.get('producto_vendido')
        p_vendido = db.session.query(Item).filter_by(nombre=producto_vendido).first()
        if p_vendido:
            if current_user.can_sell(p_vendido):
                p_vendido.vender(current_user)
                flash(f"Enhorabuena, has vendido {p_vendido.nombre}", category="success")
            else:
                flash(f"Error a la hora de vender {p_vendido.nombre}", category="danger")

        return redirect(url_for("market_page"))

    if request.method =="GET":
        items = db.session.query(Item).filter_by(owner=None)
        mis_productos = db.session.query(Item).filter_by(owner=current_user.id)
        return render_template("market.html", items=items, purchase_form=purchase_form, mis_productos=mis_productos, sell_form=sell_form)
@app.route("/registro", methods=["GET", "POST"])
def register_page():
    form = RegisterForm()
    if form.validate_on_submit():
        user_to_create = User(usuario=form.usuario.data,
                              email=form.email.data,
                              password=form.password1.data)
        db.session.add(user_to_create)
        db.session.commit()
        login_user(user_to_create)
        flash(f"Cuenta creada correctamente. Has iniciado sesión como {user_to_create}.",category="success")
        return redirect(url_for("market_page"))
    if form.errors != {}: # Si no hay errores de validación
        for err_msg in form.errors.values():
            flash(f"Error a la hora de crear usuario: {err_msg}", category="danger")
    return render_template("registro.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login_page():
    form=LoginForm()
    if form.validate_on_submit():
        attempted_user = db.session.query(User).filter_by(usuario=form.usuario.data).first()
        if attempted_user and attempted_user.check_password_correction(
                attempted_password=form.password.data
        ):
            login_user(attempted_user)
            flash(f"Has iniciado sesión como {attempted_user.usuario}", category="success")
            return redirect(url_for("market_page"))
        else:
            flash("Usuario y/o contraseña incorrectos. Inténtelo de nuevo.", category="danger")


    return render_template("login.html", form=form)

@app.route("/logout")
def logout_page():
    logout_user()
    flash("Has cerrado sesión correctamente.", category="info")
    return redirect(url_for("home_page"))

if __name__ == "__main__":
    db.Base.metadata.create_all(db.engine)
    app.run(debug=True)

