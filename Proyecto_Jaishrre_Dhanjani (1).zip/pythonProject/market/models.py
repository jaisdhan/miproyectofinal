from sqlalchemy.orm import relationship
from market import bcrypt
from market import db, login_manager
from sqlalchemy import Column, Integer, String, ForeignKey
from flask_login import UserMixin

@login_manager.user_loader
def load_user(user_id):
    return db.session.query(User).get(int(user_id))

class User(db.Base, UserMixin):
    __tablename__ = "user"
    id = Column(Integer(), primary_key=True)
    usuario = Column(String(length=30), nullable=False, unique=True)
    email = Column(String(length=50), nullable=False, unique=True)
    password_hash = Column(String(length=60), nullable=False)
    presupuesto = Column(Integer(), nullable=False, default=1000)
    productos = relationship("Item", backref='owned_user', lazy=True)

    @property
    def password(self):
        return self.password

    @password.setter
    def password(self, plain_text_password):
        self.password_hash = bcrypt.generate_password_hash(plain_text_password).decode("utf-8")

    def check_password_correction(self, attempted_password):
        return bcrypt.check_password_hash(self.password_hash, attempted_password)

    def can_purchase(self, item_obj):
        return self.presupuesto >= item_obj.precio

    def can_sell(self, item_obj):
        return item_obj in self.productos


    def __repr__(self):
        return self.usuario

class Item(db.Base):
    __tablename__ = "item"
    id = Column(Integer(), primary_key=True)
    nombre = Column(String(length=30), nullable=False, unique=True)
    precio = Column(Integer(), nullable=False)
    barcode = Column(String(length=12),nullable=False, unique=True)
    descripcion = Column(String(length=1024), nullable=False, unique=True)
    stock = Column(Integer(), nullable=False)
    owner = Column(Integer(), ForeignKey('user.id'))

    def __repr__(self):
        return self.nombre

    def comprar(self, us):
        self.owner = us.id
        us.presupuesto -= self.precio
        db.session.commit()

    def vender(self, us):
        self.owner = None
        us.presupuesto += self.precio
        db.session.commit()