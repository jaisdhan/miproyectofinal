from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import Length, EqualTo, Email, DataRequired, ValidationError
from market.models import User
from market import db


class RegisterForm(FlaskForm):
    def validate_usuario(self, usuario_to_check):
        if db.session.query(User).filter_by(usuario=usuario_to_check.data).first():
            raise ValidationError('Usuario existente. Pruebe con otro nombre de usuario')

    def validate_email(self, email_to_check):
        email= db.session.query(User).filter_by(email=email_to_check.data).first()
        if email:
            raise ValidationError("Email en uso. Introduzca otro email, por favor.")


    usuario = StringField(label="Usuario", validators=[Length(min=2, max=30), DataRequired()])
    email = StringField(label="Email", validators=[Email(),DataRequired()])
    password1 = PasswordField(label="Contraseña", validators=[Length(min=6),DataRequired()])
    password2 = PasswordField(label="Confirmar Contraseña", validators=[EqualTo("password1"),DataRequired()])
    crear = SubmitField(label="Registrate")


class LoginForm(FlaskForm):
    usuario=StringField(label="Usuario", validators=[DataRequired()])
    password=PasswordField(label="Contraseña", validators=[DataRequired()])
    submit=SubmitField(label="Iniciar Sesión")

class PurchaseItemForm(FlaskForm):
    submit = SubmitField(label='Comprar Producto')

class SellItemForm(FlaskForm):
    submit = SubmitField(label='Vender Producto')